<template>
  <div class="settingsContainer">
		<section class="painContainer">
    	<h2 class="painTitle"> Pain Input </h2>
			<p class="input"> One is little pain, 10 is high pain </p> 
			<select v-model="selected" class="pain">
				<option class="one"> 1 </option>
				<option class="two"> 2 </option>
				<option class="three"> 3 </option>
				<option class="four"> 4 </option>
				<option class="five"> 5 </option>
				<option class="six"> 6 </option>
				<option class="seven"> 7 </option>
				<option class="eight"> 8 </option>
				<option class="nine"> 9 </option>
				<option class="ten"> 10 </option>
			</select>
		</section>
  </div>
</template>

<script>
export default {
  components: { 
  },
  props: {

  }, 
  data() {
    return {
			selected: '',
    };
  },
};
</script>

<style>
body {
  background-color: white;
}

.painContainer {
	font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
	text-align: center;
}

.painTitle {
	color: #071E47;
}

.input {
	font-size: 20px;
}

.pain {
	display: inline;
}
</style>