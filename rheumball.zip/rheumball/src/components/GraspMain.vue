<template>
  <div class="mainContainer">
    <section class="overviewContainer">
      <h2 class="overviewTitle"> Overview </h2>
      <p class="overview"> Welcome to GRASP,
      a platform for monitoring and assessing changes in condition for patients with early-stage Rheumatoid Arthritis!
      Please use our site and connected products 
      as an aide for conversations with medical professionals and for monitoring your own condition over time.
      </p>
    </section>
    <section class="instructionContainer">
      <h2 class="instructionTitle"> Instructions </h2>
      <p class="instruction"> 1. Sync the RheumBall to the device's code located on its side.
      Please use voice to speech if typing is strenuous (if your device allows). <br/> 
      2. Turn on the RheumBall! Place the electrodes on your arm as indicated in the image below.
      When ready to start the test, 
      click the magenta pulse button on the application's screen to begin test and EMG reception. <br/>
      3. Follow the voice instructions of the RheumBall in order (squeeze, twist, pluck, etc).
      EMG signals will be logged and can be compared in Test History.<br/>
      4. Congratulations, you have completed one test! 
      Retake the test at another time to log new information about how you are doing.
      </p>
    </section>
    <section class="scoreContainer" @click="startTest">
      <img class="pulse" src="./instructions.png">
      <p class="output" v-show="progress"> {{items}} </p>
      <p class="testing"> {{message}} </p>
    </section> 
    <section class="historyContainer">
      <h2 class="historyTitle"> Testing History </h2>
      <img class="history" src="./history.png">
    </section> 
  </div>
</template>

<script>
import axios from 'axios';

export default {
  components: { 
  },
  props: {

  }, 
  data() {
    return {
      message: "Begin Test",
      progress: false,
      itemsEndpoint: 'https://es9c4nd79i.execute-api.us-west-2.amazonaws.com/prod',
      items: '',
    };
  },
  methods: {
    getData() {
      axios.get(this.itemsEndpoint).then((response) => {
        this.items = response.data;
      }).catch((error) => {
        console.log(error);
      });
    },
    startTest() {
      this.message = 'GRASP Score';
      this.progress = true;
      this.getData();
    },
  },
};
</script>

<style>
@import url(https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css);
body {
  background-color: white;
}

.mainContainer {
  font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
}

.overviewTitle {
  color: #071E47;
  padding-left: 50px;
}

.overview {
  padding-left: 60px;
  font-size: 18px;
}

.instructionTitle {
  color: #071E47;
  padding-left: 50px;
}

.instruction {
  padding-left: 60px;
  font-size: 18px;
}

.output {
  font-size: 30px;
}

.scoreContainer {
  padding: 50px;
  text-align: center;
}

.testing {
  font-size: 25px;
}

.historyTitle {
  padding: 0px;
  color: #071E47;
}

.historyContainer {
  text-align: center;
}

</style>