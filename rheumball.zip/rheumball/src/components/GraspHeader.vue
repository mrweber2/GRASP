<template>
 <div class="headerContainer">
    <h1 class="headerTitle" @click="showMain"> <img class=logo src="./logo.png">
 GRASP </h1>
    <nav class="headerLinks">
        <a href="#" class="navLinks" @click="showSettings"> <img class=settings src="./settings.png">Settings</a> 
    </nav>
 </div>
</template>

<script>
export default {
  data() {
    return {};
  },
  methods: {
    showSettings() {
      this.$emit('openSettings');
    },
    showMain() {
      this.$emit('openMain');
    },
  },
  props: {

  },
  computed: {

  }
};
</script>

<style>
@import url(https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css);

.headerContainer {
    display: grid;
    grid-template-columns: 1fr 50% 15%;
    grid-template-areas: "left middle right";
    background: #FF1E8A;
}

.headerTitle {
    grid-area: left;
    align-self: center;
    color: #071E47;
    cursor: pointer;
}

.headerLinks {
  display: flex;
  flex-flow: row wrap;
  grid-area: right;
  align-items: center;
}

header {
  font-weight: bold;
  font-family: 'Roboto';
  font-size: 18px;
}

h1 {
  font-size: 36px;
  font-family: 'Verdana';
  padding-left: 50px; 
}

body {
  background-color: white;
}

.navLinks {
  font-family: 'Ubuntu', sans-serif;
  font-size: 18px;
  font-weight: bold;
  text-transform: uppercase;
  text-decoration: none;
  color: #071E47;
  min-width: 150px;
}

.logo {
  width: 80px;
  height: 80px;
}
</style>

