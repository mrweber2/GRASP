<template>
 <div id="app">
   <grasp-header class="header" @openSettings="openSettings()" @openMain="openMain()"/> 
   <grasp-main class="main" v-show="!showSettings"/>
   <grasp-settings class="settings" v-show="showSettings"/>
  </div>
</template>

<script>
import GraspHeader from './components/GraspHeader';
import GraspMain from './components/GraspMain';
import GraspSettings from './components/Settings';

export default {
  name: 'App', 
  components: {
    GraspHeader, 
    GraspMain,
    GraspSettings,
  },
  data() {
    return {
      showSettings: false,
    };
  },
  methods: {
    openSettings() {
      this.showSettings = true;
    },
    openMain() {
      this.showSettings = false;
    }
  },
};
</script>

<style>
#app {
  display: grid;
  grid-template-rows: 150px 1fr;
  grid-template-areas: "header"
                        "main";
}

.header {
  grid-area: header;
  background-color: white;
}

.main {
  grid-area: main;
}

.settings {
  grid-area: main;
}

body {
  margin: 0px;
}
</style>

